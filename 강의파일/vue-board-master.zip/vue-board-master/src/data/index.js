export default [
  {
    writer: '아이린',
    title: '레드벨벳',
    content: '1'
  },
  {
    writer: '슬기',
    title: '레드벨벳2',
    content: '2'
  },
  {
    writer: '웬디',
    title: '레드벨벳3',
    content: '3'
  }
]